#!/bin/bash

BRIDGE="br0"
IFACE="eth0"
NETPLAN_FILE="/etc/netplan/50-cloud-init.yaml"

# ログ関数（必要なら）
log() {
  echo "$(date '+%F %T') $1"
}

# eth0 がリンクアップしているか？
if ! ip link show "$IFACE" | grep -q "LOWER_UP"; then
    # リンクダウン → br0 から外す
    sudo brctl delif "$BRIDGE" "$IFACE" 2>/dev/null
    sudo dhclient "$IFACE"
    exit 0
fi

# 2秒待って ARP を観察
sleep 2
#NEIGH_COUNT=$(sudo ip neigh show dev "$IFACE" | wc -l)
NEIGH_COUNT=$(sudo ip neigh show dev br0 | grep -v FAILED | wc -l)
if [ "$NEIGH_COUNT" -eq 0 ]; then
  sleep 10
  NEIGH_COUNT=$(sudo ip neigh show dev br0 | grep -v FAILED | wc -l)
  if [ "$NEIGH_COUNT" -eq 0 ]; then
    sleep 20
    NEIGH_COUNT=$(sudo ip neigh show dev br0 | grep -v FAILED | wc -l)
  fi
fi

# eth0 が br0 にすでに追加されているか？
is_bridged=$(brctl show "$BRIDGE" | grep -w "$IFACE")


# netplan で eth0 の dhcp4 が no または false か確認
#if grep -A 5 "eth0:" "$NETPLAN_FILE" | grep -Eq "dhcp4:\s*(no|false)"; then
if awk '/eth0:/, /^[^[:space:]]/ { print }' "$NETPLAN_FILE" | grep -Eq "dhcp4:\s*(no|false)"; then
    is_dhcp_disabled="yes"
else
    is_dhcp_disabled="no"
fi

# 条件1: netplanでdhcp4: no、かつブリッジ未追加 → Halowと判定
if [ "$is_dhcp_disabled" = "yes" ] && [ -z "$is_bridged" ]; then
    echo "Halow detected: bridging $IFACE → $BRIDGE"
    sudo ip addr flush dev "$IFACE"
    sudo brctl addif "$BRIDGE" "$IFACE"
    sudo ip link set "$IFACE" down
    sudo ip link set "$IFACE" up
    exit 0
fi

# 条件2: ARPが0、かつブリッジ未追加 → Halowと判定
#if [ "$NEIGH_COUNT" -eq 0 ] && [ -z "$is_bridged" ]; then
if [ "$NEIGH_COUNT" -eq 0 ]; then
    echo "Halow detected: bridging $IFACE → $BRIDGE"
    sudo ip addr flush dev "$IFACE"
    if [ -z "$is_bridged" ]; then
      sudo brctl addif "$BRIDGE" "$IFACE"
    fi
    sudo ip link set "$IFACE" down
    sudo ip link set "$IFACE" up
    exit 0
fi

