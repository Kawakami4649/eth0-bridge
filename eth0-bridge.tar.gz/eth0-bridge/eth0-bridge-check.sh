#!/bin/bash

# TinyBox Network Interface
if [ -f /etc/tinybox/network.conf ]; then
    source /etc/tinybox/network.conf
fi
ETH_IF="${ETH_IF:-eth0}"
WLAN_IF="${WLAN_IF:-wlan0}"

BRIDGE="br0"
#IFACE="eth0"
IFACE="$ETH_IF"
LOGTAG="eth0-bridge-cehck"

log()
{
    logger -t "$LOGTAG" "$*"
    echo "$(date '+%F %T') $*"
}

bridge_exists()
{
    ip link show "$BRIDGE" >/dev/null 2>&1
}

iface_exists()
{
    ip link show "$IFACE" >/dev/null 2>&1
}

link_up()
{
    ip link show "$IFACE" | grep -q LOWER_UP
}

is_bridged()
{
    bridge link show dev "$IFACE" 2>/dev/null | grep -q "master $BRIDGE"
}

get_eth0_cidr()
{
    ip -4 -o addr show "$IFACE" 2>/dev/null | awk '{print $4}' | head -n1
}

get_br0_cidr()
{
    ip -4 -o addr show "$BRIDGE" 2>/dev/null | awk '{print $4}' | head -n1
}

same_subnet()
{
    local cidr1="$1"
    local cidr2="$2"

    local ip1=${cidr1%/*}
    local mask1=${cidr1#*/}
    local ip2=${cidr2%/*}
    local mask2=${cidr2#*/}

    [ "$mask1" != "$mask2" ] && return 1

    if [ "$mask1" = "24" ]; then
        local net1
        local net2

        net1=$(echo "$ip1" | cut -d. -f1-3)
        net2=$(echo "$ip2" | cut -d. -f1-3)

        [ "$net1" = "$net2" ]
        return $?
    fi

    return 1
}

should_join_bridge()
{
    local eth_cidr
    local br_cidr

    eth_cidr=$(get_eth0_cidr)
    br_cidr=$(get_br0_cidr)

    if [ -z "$eth_cidr" ]; then
        log "eth0 has no IPv4"
        return 0
    fi

    if echo "$eth_cidr" | grep -q '^169\.254\.'; then
        log "eth0 has APIPA address"
        return 0
    fi

    if [ -z "$br_cidr" ]; then
        log "br0 has no IPv4"
        return 1
    fi

    if same_subnet "$eth_cidr" "$br_cidr"; then
        log "eth0 and br0 are same subnet"
        return 0
    fi

    log "eth0 and br0 are different subnet"
    return 1
}

join_bridge()
{
    if is_bridged; then
        log "$IFACE already joined"
        return 0
    fi

    log "Adding $IFACE to $BRIDGE"

    if ip link set "$IFACE" master "$BRIDGE"; then
        sleep 1

        if is_bridged; then
            log "$IFACE joined $BRIDGE"
            return 0
        fi
    fi

    log "Join failed"
    return 1
}

leave_bridge()
{
    if ! is_bridged; then
        return 0
    fi

    log "Removing $IFACE from $BRIDGE"

    if ip link set "$IFACE" nomaster; then
        sleep 1

        if ! is_bridged; then
            log "$IFACE removed from $BRIDGE"
            return 0
        fi
    fi

    log "Remove failed"
    return 1
}

log "===== start ====="

if ! bridge_exists; then
    log "Bridge $BRIDGE not found"
    exit 1
fi

if ! iface_exists; then
    log "Interface $IFACE not found"
    exit 1
fi

if ! link_up; then
    log "$IFACE link down"
    leave_bridge
    exit 0
fi

if ! should_join_bridge; then
    log "Bridge condition not satisfied"
    leave_bridge
    exit 0
fi

if join_bridge; then
    log "Bridge active"
    exit 0
fi

log "Bridge join failed"
exit 1
