sudo cp --preserve=timestamps eth0-bridge-cehck3.sh /usr/local/bin/eth0-bridge-check.sh
sudo cp --preserve=timestamps eth0-bridge-check.service /etc/systemd/system/
sudo cp --preserve=timestamps eth0-bridge-check.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now eth0-bridge-check.timer

